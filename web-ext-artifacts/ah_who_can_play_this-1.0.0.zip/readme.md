```
 web-ext sign --channel=unlisted --api-key=$AMO_JWT_ISSUER --api-secret=$AMO_JWT_SECRET
 web-ext build --overwrite-dest 
 ```

Chrome
 ```
   "background": {
    "service_worker": "background.js"
  },
  ```

  Firefox
 ```
  "background": {
    "scripts": [
      "background.js"
    ]
  },
  "browser_specific_settings": {
    "gecko": {
      "id": "StickWithKuna@bulaxy.dev"
    }
  }
  ```